
import pandas as pd
from sklearn.linear_model import LinearRegression
import pickle
import os

def train_model():
    df = pd.read_csv("data/sample_data.csv")
    X = df[["heart_rate"]]
    y = df["systolic_bp"]
    model = LinearRegression()
    model.fit(X, y)
    with open("models/bp_model.pkl", "wb") as f:
        pickle.dump(model, f)
    print("Model trained and saved.")

if __name__ == "__main__":
    os.makedirs("models", exist_ok=True)
    train_model()
