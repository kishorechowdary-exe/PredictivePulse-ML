
from flask import Blueprint, render_template, request
import pickle
import numpy as np

bp_blueprint = Blueprint('bp', __name__)

with open("models/bp_model.pkl", "rb") as f:
    model = pickle.load(f)

@bp_blueprint.route('/', methods=["GET", "POST"])
def index():
    prediction = None
    if request.method == "POST":
        heart_rate = float(request.form["heart_rate"])
        prediction = model.predict(np.array([[heart_rate]]))[0]
    return render_template("index.html", prediction=prediction)
